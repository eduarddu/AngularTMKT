SELECT 
	ACO_CODIGO,
	ACO_SIGLA,
	SMS_LOTE, 
	SMS_TIPO_ENVIO,
	SMS_DATAENVIO,
	COUNT(distinct sms_clicodigo),
	COUNT(DISTINCT CASE WHEN SMS_REPOSTA_VENDA = 1 and ass_agtcodigo = 'sistema' THEN ASS_cliCODIGO ELSE NULL END),
	--COUNT(DISTINCT CASE WHEN ass_agtcodigo = 'SISTEMA' THEN ass_clicodigo ELSE NULL END),
	COUNT(DISTINCT CASE WHEN SMS_REPOSTA_VENDA = 1 AND ASS_STACODIGO = 2 and ass_agtcodigo = 'sistema' and ass_datahora >= sms_dataenvio THEN ASS_cliCODIGO ELSE NULL END)
	--COUNT(DISTINCT CASE WHEN ASS_STACODIGO = 2 and ass_agtcodigo = 'sistema' and ass_datahora >= sms_dataenvio THEN ASS_cliCODIGO ELSE NULL END)
fROM 
	TB_SMS_CONTATO SMS
	INNER JOIN TB_CLIENTE ON (CLI_CODIGO = SMS_CLICODIGO)
	INNER JOIN TMKT.DBO.TB_CAMPANHA ON (CMP_CODIGO = CLI_CMPCODIGO)
	INNER JOIN TMKT.DBO.TB_ACAO ON (ACO_CODIGO = CMP_ACOCODIGO)
	left join tb_associados on (ass_clicodigo = sms_clicodigo)
where
	--*sms_dataenvio >= '2022-02-01'
	CMP_MESREFERENCIA = '2022-04-01'
	--AND ACO_CODIGO = 1741
	--and sms_lote between 57 and 68
	--AND SMS_LOTE NOT IN (61,62)
	and sms_lote >= 127
	--and sms_datahora_envio <= '2022-02-02 20:00:00'
	--and sms_lote = 12
GROUP BY
	ACO_CODIGO,
	ACO_SIGLA,
	sms_lote,
	SMS_DATAENVIO,
	SMS_TIPO_ENVIO
ORDER BY
	3,1,2,4
compute 
	sum(COUNT(distinct sms_clicodigo)),
	sum(COUNT(DISTINCT CASE WHEN SMS_REPOSTA_VENDA = 1 and ass_agtcodigo = 'sistema' THEN ASS_cliCODIGO ELSE NULL END)),
	sum(COUNT(DISTINCT CASE WHEN SMS_REPOSTA_VENDA = 1 AND ASS_STACODIGO = 2 and ass_agtcodigo = 'sistema' and ass_datahora >= sms_dataenvio THEN ASS_cliCODIGO ELSE NULL END))





--select * from tb_sms_contato where sms_CTSCODIGO = 5910292

--select * from tb_associados where ass_agtcodigo = 'SISTEMA' AND ASS_DATAHORA BETWEEN '2022-02-02' AND '2022-02-03'


--SELECT * FROM TB_CONTATO WHERE CTO_CLICODIGO = 2159882

--UPDATE tb_sms_contato SET SMS_REPOSTA_VENDA = 1 WHERE SMS_CTSCODIGO = 5910292



